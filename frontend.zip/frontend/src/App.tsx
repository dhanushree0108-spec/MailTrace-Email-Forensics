/**
 * Application root and router.
 *
 * Routing is hash-based (`#/queue`, `#/case/MT-2026-0007`) rather than history
 * API. The reason is deployment: the built console is a pile of static files a
 * judge might open from a plain file server or `python -m http.server`, and
 * hash routes survive a hard refresh there without any server-side rewrite. The
 * stdlib backend also serves `index.html` for unknown non-API paths, so history
 * routing would work behind it — but the console must not depend on being behind
 * it, so hash routing is the portable choice.
 *
 * Everything below the ThemeProvider reads preferences through `usePrefs`, so
 * the live-feed toggle, the theme and the density all take effect without a
 * reload. The two server-backed screens the rebuilt views did not cover —
 * campaigns and server settings — are implemented inline here rather than as
 * separate files, because each is a single read and a single table.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import { ThemeProvider, usePrefs } from '@/lib/theme';
import { Shell, type Route } from '@/components/Shell';
import { Scene } from '@/components/Scene';
import { Dashboard } from '@/views/Dashboard';
import { Ingest } from '@/views/Ingest';
import { Queue } from '@/views/Queue';
import { Investigator } from '@/views/Investigator';
import { Card, Panel, Toggle, KV as KeyValue, Chip, Empty, useToasts, Mono, Button } from '@/components/ui';
import { Trash2 } from 'lucide-react';
import { useLiveEvents } from '@/lib/live';
import { api } from '@/lib/api';
import type { CampaignRow, ConfigPayload } from '@/lib/types';

/** Serialise a route to a hash fragment, and back. One function each way so the
 *  two can be read together and kept inverse. */
function routeToHash(r: Route): string {
  if (r.name === 'case') return `#/case/${encodeURIComponent(r.ref)}`;
  return `#/${r.name}`;
}

function hashToRoute(hash: string): Route {
  const parts = hash.replace(/^#\/?/, '').split('/');
  const name = parts[0] || 'dashboard';
  if (name === 'case' && parts[1]) return { name: 'case', ref: decodeURIComponent(parts[1]) };
  if (['dashboard', 'ingest', 'queue', 'campaigns', 'settings'].includes(name)) {
    return { name } as Route;
  }
  return { name: 'dashboard' };
}

function AppInner() {
  const { prefs } = usePrefs();
  const [route, setRoute] = useState<Route>(() => hashToRoute(window.location.hash));
  const [campaignFilter, setCampaignFilter] = useState<string | undefined>();
  const live = useLiveEvents(prefs.liveFeed);
  const { add: toast, view: toasts } = useToasts();

  // The hash is the single source of truth. `navigate` writes it; a `hashchange`
  // listener reads it. That means the browser back button, a bookmarked case URL
  // and an in-app click all funnel through the same path and cannot disagree.
  const navigate = useCallback((r: Route) => {
    const next = routeToHash(r);
    if (window.location.hash !== next) window.location.hash = next;
    else setRoute(r); // same hash (e.g. re-click): update state directly
  }, []);

  useEffect(() => {
    const onHash = () => setRoute(hashToRoute(window.location.hash));
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // Auto-follow the newest case onto the investigator when the user asked for
  // it. Guarded so it only fires on a genuinely new case event, never on replay.
  useEffect(() => {
    if (!prefs.followNewCases) return;
    const last = live.events[live.events.length - 1];
    const caseNumber = last?.data?.case_number;
    if (last?.kind === 'case' && (typeof caseNumber === 'string' || typeof caseNumber === 'number')) {
      navigate({ name: 'case', ref: String(caseNumber) });
    }
  }, [live.events, prefs.followNewCases, navigate]);

  const body = useMemo(() => {
    switch (route.name) {
      case 'dashboard':
        return <Dashboard navigate={navigate} events={live.events} />;
      case 'ingest':
        return <Ingest navigate={navigate} events={live.events} toast={toast} />;
      case 'queue':
        return <Queue navigate={navigate} campaignFilter={campaignFilter} toast={toast} />;
      case 'campaigns':
        return <Campaigns onPick={(id) => { setCampaignFilter(id); navigate({ name: 'queue' }); }} toast={toast} />;
      case 'settings':
        return <ServerSettings toast={toast} />;
      case 'case':
        return <Investigator caseRef={route.ref} navigate={navigate} toast={toast} />;
      default:
        return <Empty title="Not found" hint="That view does not exist." />;
    }
  }, [route, navigate, live.events, toast, campaignFilter]);

  // Clear the campaign filter whenever the user leaves the queue by another
  // route, so it does not silently apply the next time they open the queue.
  useEffect(() => {
    if (route.name !== 'queue' && route.name !== 'campaigns') setCampaignFilter(undefined);
  }, [route.name]);

  return (
    <>
      {prefs.backdrop && <Scene />}
      <Shell route={route} navigate={navigate}
        live={live.status}
        onCommand={(q) => { navigate({ name: 'queue' }); console.debug('search', q); }}>
        {body}
      </Shell>
      {toasts}
    </>
  );
}

/** Campaign roll-up. Grouping many cases into one wave is a PS-26106 requirement
 *  ("group related emails into campaigns"), so it gets a first-class screen. */
function Campaigns({ onPick, toast }: Readonly<{ onPick: (id: string) => void; toast?: (m: string, tone?: 'info' | 'critical' | 'low') => void }>) {
  const [rows, setRows] = useState<CampaignRow[] | null>(null);
  const [clearing, setClearing] = useState(false);

  const fetchCampaigns = () => {
    api.campaigns().then((r) => setRows((r.campaigns ?? []) as CampaignRow[]))
      .catch(() => setRows([]));
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const handleClearAll = async () => {
    if (!window.confirm('Are you sure you want to clear all campaigns, cases and evidence?')) return;
    setClearing(true);
    try {
      const res = await api.clearCases();
      toast?.(`Cleared ${res.purged} case(s) and associated campaigns`, 'low');
      fetchCampaigns();
    } catch {
      toast?.('Failed to clear campaigns', 'critical');
    } finally {
      setClearing(false);
    }
  };

  if (rows?.length === 0) {
    return <Empty title="No campaigns yet" hint="Ingest a wave of related mail to see it grouped here." />;
  }
  return (
    <div className="animate-rise-in">
      <div className="flex items-start justify-between gap-4 mb-4 flex-wrap">
        <div>
          <h1 className="mb-1 text-lg font-semibold">Campaigns</h1>
          <p className="text-sm text-dim">
            Cases sharing a fingerprint — sender, subject shape and infrastructure, but
            not recipient — collapse into one wave.
          </p>
        </div>
        {Boolean(rows?.length) && (
          <Button size="sm" variant="danger" onClick={handleClearAll} disabled={clearing}>
            <Trash2 size={14} /> {clearing ? 'Clearing…' : 'Clear all campaigns'}
          </Button>
        )}
      </div>
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {(rows ?? Array.from({ length: 3 })).map((c, i) => (
          <Card key={c?.campaign_id ?? i} className="cursor-pointer lift"
            onClick={() => c && onPick(c.campaign_id)}>
            {c ? (
              <>
                <div className="flex items-center justify-between mb-2">
                  <Mono className="text-xs text-dim">{c.campaign_id}</Mono>
                  <Chip tone={riskTone(c.max_risk)}>
                    max risk {Math.round(c.max_risk)}
                  </Chip>
                </div>
                <div className="mb-2 text-sm font-medium truncate">
                  {c.sender_domains?.join(', ') || 'Unknown sender domain'}
                </div>
                <KeyValue rows={[
                  ['Cases', String(c.cases)],
                  ['Phishing cases', String(c.phishing_cases ?? '—')],
                  ['First seen', (c.first_seen || '').slice(0, 16).replace('T', ' ')],
                ]} />
              </>
            ) : <div className="h-24 skeleton" />}
          </Card>
        ))}
      </div>
    </div>
  );
}

function riskTone(risk: number): 'critical' | 'medium' | 'low' {
  if (risk >= 75) return 'critical';
  if (risk >= 40) return 'medium';
  return 'low';
}

/** Server-side analysis settings. These change verdicts, so unlike the
 *  appearance drawer they live on the backend and are the same for every
 *  analyst. The panel patches them one field at a time and reports the result. */
function ServerSettings({ toast }: Readonly<{ toast: (m: string, tone?: 'info' | 'critical' | 'low') => void }>) {
  const [cfg, setCfg] = useState<ConfigPayload | null>(null);
  const [busy, setBusy] = useState(false);
  const [clearing, setClearing] = useState(false);
  const load = useCallback(() => { api.config().then(setCfg).catch(() => setCfg(null)); }, []);
  useEffect(load, [load]);

  const patch = async (key: string, value: unknown) => {
    setBusy(true);
    try {
      const next = await api.patchConfig({ [key]: value });
      setCfg(next);
      toast(`Updated ${key}`, 'low');
    } catch (e) {
      toast(`Rejected: ${(e as Error).message}`, 'critical');
      load(); // pull the server's actual state back after a rejected patch
    } finally { setBusy(false); }
  };

  const handleClearAll = async () => {
    if (!window.confirm('WARNING: This will permanently purge all cases, IOC records, and blockchain evidence receipts. Proceed?')) return;
    setClearing(true);
    try {
      const res = await api.clearCases();
      toast(`Cleared ${res.purged} case(s) from database`, 'low');
    } catch {
      toast('Failed to clear database', 'critical');
    } finally {
      setClearing(false);
    }
  };

  if (!cfg) return <Empty title="Settings unavailable" hint="Server settings need a live backend; the demo snapshot is read-only." />;
  const s = cfg.settings;
  const num = (k: string) => Number(s[k]);

  return (
    <div className="max-w-3xl animate-rise-in">
      <h1 className="mb-1 text-lg font-semibold">Analysis settings</h1>
      <p className="mb-4 text-sm text-dim">
        These are server-side and shared by every analyst, because they change how
        cases are scored. Appearance settings are separate — open the drawer from the top bar.
      </p>
      <Panel title="Decision thresholds" subtitle="Where the agent stops on its own vs. asks a human">
        <label className="block mb-3 text-sm">
          Conclusively safe below: <b>{num('conclusive_low')}</b>
          <input type="range" className="mt-1 field" min={1} max={49} value={num('conclusive_low')}
            disabled={busy} onChange={(e) => patch('conclusive_low', Number(e.target.value))} />
        </label>
        <label className="block text-sm">
          Conclusively malicious above: <b>{num('conclusive_high')}</b>
          <input type="range" className="mt-1 field" min={51} max={99} value={num('conclusive_high')}
            disabled={busy} onChange={(e) => patch('conclusive_high', Number(e.target.value))} />
        </label>
      </Panel>
      <Panel title="Operations" className="mt-3">
        <label className="block mb-3 text-sm">
          SLA target (minutes): <b>{num('sla_minutes')}</b>
          <input type="range" className="mt-1 field" min={5} max={120} step={5} value={num('sla_minutes')}
            disabled={busy} onChange={(e) => patch('sla_minutes', Number(e.target.value))} />
        </label>
        <label className="block text-sm">
          Retention (days): <b>{num('retention_days')}</b>
          <input type="range" className="mt-1 field" min={1} max={365} value={num('retention_days')}
            disabled={busy} onChange={(e) => patch('retention_days', Number(e.target.value))} />
        </label>
      </Panel>
      <Panel title="Privacy & safety switches" className="mt-3">
        {([
          ['pii_masking', 'Mask PII in shared views and reports'],
          ['allow_network', 'Allow live threat-intel lookups'],
          ['allow_detonation', 'Allow sandbox URL detonation'],
          ['demo_mode', 'Demo mode (deterministic, no external calls)'],
        ] as const).map(([k, label]) => (
          <div key={k} className="flex items-center justify-between py-2 row-hair">
            <span className="text-sm">{label}</span>
            <Toggle on={Boolean(s[k])} disabled={busy} onChange={(v) => patch(k, v)} />
          </div>
        ))}
      </Panel>
      
      <Panel title="Database & storage management" subtitle="Reset test evidence and imported emails" className="mt-3">
        <div className="flex items-center justify-between py-2">
          <div>
            <div className="text-sm font-medium text-red-400">Purge all imported cases & evidence</div>
            <div className="text-xs text-dim">Instantly resets the triage queue, campaigns, and evidence store to a clean 0-case state.</div>
          </div>
          <Button variant="danger" size="sm" onClick={handleClearAll} disabled={clearing}>
            <Trash2 size={14} /> {clearing ? 'Purging…' : 'Purge all data'}
          </Button>
        </div>
      </Panel>

      <p className="mt-3 text-xs text-faint">
        Credentials are deliberately not editable here — an API that can set an API
        key is an API that can leak one. Put keys in <Mono>.env</Mono>.
      </p>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}

