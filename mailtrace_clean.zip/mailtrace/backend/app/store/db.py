"""Case persistence: SQLite, with the same shape as the Supabase schema.

Design notes:

* **One JSON document plus indexed columns.** The full case is stored as JSON
  (``payload``) and the fields the queue filters and sorts on are mirrored into
  real columns. A fully normalised schema across twenty tables would be slower to
  evolve and would not buy anything here, because a case is always read whole.
* **Search is a first-class feature**, not a ``LIKE`` afterthought: PS-26106 asks
  for searchable case management with campaign grouping. FTS5 is used when the
  local SQLite build has it, and there is a deterministic ``LIKE`` fallback so the
  feature never simply vanishes - :func:`CaseStore.search_backend` reports which
  one is live.
* **Evidence and application state are separate.** This database holds case state;
  the custody chain lives in its own append-only trail, and purging content here
  never touches it.
* **stdlib only.** ``sqlite3`` ships with Python, so the whole backend runs with
  zero installs; ``DATABASE_URL`` is honoured by the optional Supabase mirror
  instead of by swapping the driver here.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from ..config import get_settings
from ..schemas import Case, utcnow

log = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS cases (
    id                TEXT PRIMARY KEY,
    case_number       TEXT UNIQUE NOT NULL,
    status            TEXT NOT NULL,
    verdict           TEXT,
    threat_class      TEXT,
    risk_score        REAL DEFAULT 0,
    confidence        REAL DEFAULT 0,
    actor_type        TEXT,
    subject           TEXT,
    sender_address    TEXT,
    sender_domain     TEXT,
    recipient         TEXT,
    email_hash        TEXT,
    fingerprint       TEXT,
    campaign_id       TEXT,
    is_duplicate      INTEGER DEFAULT 0,
    origin_country    TEXT,
    origin_ip         TEXT,
    requires_review   INTEGER DEFAULT 1,
    action_status     TEXT,
    analyst           TEXT,
    tx_hash           TEXT,
    chain_simulated   INTEGER DEFAULT 1,
    report_path       TEXT,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    completed_at      TEXT,
    payload           TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cases_created   ON cases(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cases_status    ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_verdict   ON cases(verdict);
CREATE INDEX IF NOT EXISTS idx_cases_campaign  ON cases(campaign_id);
CREATE INDEX IF NOT EXISTS idx_cases_fp        ON cases(fingerprint);
CREATE INDEX IF NOT EXISTS idx_cases_risk      ON cases(risk_score DESC);

CREATE TABLE IF NOT EXISTS iocs (
    case_id    TEXT NOT NULL,
    ioc_type   TEXT NOT NULL,
    value      TEXT NOT NULL,
    confidence INTEGER DEFAULT 50,
    context    TEXT,
    first_seen TEXT,
    PRIMARY KEY (case_id, ioc_type, value)
);
CREATE INDEX IF NOT EXISTS idx_iocs_value ON iocs(value);

CREATE TABLE IF NOT EXISTS signals (
    case_id   TEXT NOT NULL,
    signal_id TEXT NOT NULL,
    title     TEXT,
    weight    REAL,
    severity  TEXT,
    category  TEXT,
    technique TEXT,
    PRIMARY KEY (case_id, signal_id)
);
CREATE INDEX IF NOT EXISTS idx_signals_technique ON signals(technique);

CREATE TABLE IF NOT EXISTS custody (
    case_id    TEXT NOT NULL,
    idx        INTEGER NOT NULL,
    action     TEXT,
    tx_hash    TEXT,
    payload_hash TEXT,
    simulated  INTEGER DEFAULT 1,
    written_at TEXT,
    PRIMARY KEY (case_id, idx)
);

CREATE TABLE IF NOT EXISTS audit (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id   TEXT,
    event     TEXT NOT NULL,
    actor     TEXT,
    detail    TEXT,
    at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_case ON audit(case_id);
"""

FTS_SCHEMA = """
CREATE VIRTUAL TABLE IF NOT EXISTS cases_fts USING fts5(
    case_id UNINDEXED, case_number, subject, sender, body, indicators, campaign_id,
    tokenize = 'porter unicode61'
);
"""

_SORTS = {
    "created": "created_at DESC",
    "risk": "risk_score DESC, created_at DESC",
    "confidence": "confidence DESC, created_at DESC",
    "updated": "updated_at DESC",
    "status": "status ASC, created_at DESC",
}


class CaseStore:
    """Thread-safe case store. One connection, guarded by a lock.

    SQLite would allow a connection per thread, but the API's WebSocket broadcaster
    and its request handlers both write, and a single serialised connection is
    simpler to reason about than per-thread connections plus WAL contention.
    """

    def __init__(self, path: Optional[str] = None):
        self.path = Path(path or get_settings().sqlite_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._fts = False
        self._init()

    # -- setup -------------------------------------------------------------

    def _init(self) -> None:
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(SCHEMA)
            try:
                self._conn.executescript(FTS_SCHEMA)
                self._fts = True
            except sqlite3.OperationalError as exc:
                # Some distro builds omit FTS5. Degrade, do not fail.
                log.info(
                    "FTS5 unavailable (%s); search falls back to LIKE", exc)
                self._fts = False
            self._conn.commit()

    @property
    def search_backend(self) -> str:
        return "fts5" if self._fts else "like"

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def clear_all(self) -> int:
        """Purge all cases, IOCs, signals, custody records, audit logs and FTS index."""
        with self._lock:
            cur = self._conn.execute("SELECT COUNT(*) FROM cases")
            count = int(cur.fetchone()[0])
            self._conn.execute("DELETE FROM cases")
            self._conn.execute("DELETE FROM iocs")
            self._conn.execute("DELETE FROM signals")
            self._conn.execute("DELETE FROM custody")
            self._conn.execute("DELETE FROM audit")
            if self._fts:
                try:
                    self._conn.execute("DELETE FROM cases_fts")
                except Exception:
                    pass
            self._conn.commit()
            return count

    # -- write -------------------------------------------------------------

    def save(self, case: Case) -> Case:
        """Insert or replace the whole case. Idempotent by case id."""
        payload = json.dumps(case.to_dict(), sort_keys=True, default=str)
        origin = case.origin or {}
        row = (
            case.id, case.case_number, case.status, case.verdict.label,
            case.verdict.threat_class, float(case.verdict.risk_score),
            float(case.verdict.confidence), case.attribution.actor_type,
            case.subject[:400], case.sender_address, case.parsed_email.from_domain,
            case.recipient, case.email_hash, case.fingerprint, case.campaign.id,
            1 if case.campaign.is_duplicate else 0,
            str(origin.get("country", origin.get("place", "")))[:120],
            str(origin.get("ip", "")), 1 if case.verdict.requires_human_review else 0,
            case.action.status, case.action.analyst,
            case.chain_receipts[-1].tx_hash if case.chain_receipts else "",
            1 if (not case.chain_receipts or case.chain_receipts[-1].simulated) else 0,
            case.report_path, case.created_at, case.updated_at or utcnow(),
            case.completed_at, payload,
        )
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO cases (id, case_number, status, verdict, "
                "threat_class, risk_score, confidence, actor_type, subject, "
                "sender_address, sender_domain, recipient, email_hash, fingerprint, "
                "campaign_id, is_duplicate, origin_country, origin_ip, requires_review, "
                "action_status, analyst, tx_hash, chain_simulated, report_path, "
                "created_at, updated_at, completed_at, payload) "
                "VALUES (%s)" %
                ",".join(
                    "?" * 28), row)
            self._conn.execute("DELETE FROM iocs WHERE case_id=?", (case.id,))
            self._conn.executemany(
                "INSERT OR REPLACE INTO iocs (case_id, ioc_type, value, confidence, "
                "context, first_seen) VALUES (?,?,?,?,?,?)",
                [(case.id, i.ioc_type, i.value, int(i.confidence), i.context, i.first_seen)
                 for i in case.iocs])
            self._conn.execute(
                "DELETE FROM signals WHERE case_id=?", (case.id,))
            self._conn.executemany(
                "INSERT OR REPLACE INTO signals (case_id, signal_id, title, weight, "
                "severity, category, technique) VALUES (?,?,?,?,?,?,?)",
                [(case.id, s.id, s.title, float(s.weight), s.severity, s.category,
                  s.mitre_technique) for s in case.signals if s.triggered])
            self._conn.executemany(
                "INSERT OR REPLACE INTO custody (case_id, idx, action, tx_hash, "
                "payload_hash, simulated, written_at) VALUES (?,?,?,?,?,?,?)",
                [(case.id, i, r.action, r.tx_hash, r.payload_hash,
                  1 if r.simulated else 0, r.written_at)
                 for i, r in enumerate(case.chain_receipts)])
            if self._fts:
                self._conn.execute(
                    "DELETE FROM cases_fts WHERE case_id=?", (case.id,))
                self._conn.execute(
                    "INSERT INTO cases_fts (case_id, case_number, subject, sender, body, "
                    "indicators, campaign_id) VALUES (?,?,?,?,?,?,?)",
                    (case.id, case.case_number, case.subject,
                     "%s %s %s" % (case.sender_display, case.sender_address,
                                   case.parsed_email.from_domain),
                     (case.parsed_email.body_text or "")[:20000],
                     " ".join(s.title for s in case.signals if s.triggered) + " " +
                     " ".join(i.value for i in case.iocs[:60]),
                     case.campaign.id))
            self._conn.commit()
        return case

    def log_event(self, case_id: str, event: str, actor: str = "system",
                  detail: str = "") -> None:
        """Application audit log. Deliberately *not* the custody chain: this is
        operational history (who opened what, which export ran), which is useful
        but not evidence."""
        with self._lock:
            self._conn.execute(
                "INSERT INTO audit (case_id, event, actor, detail, at) VALUES (?,?,?,?,?)",
                (case_id, event, actor, detail[:500], utcnow()))
            self._conn.commit()

    def next_case_number(self) -> str:
        """``MT-2026-0001``. Sequential per year so a case number is quotable in a
        ticket and sorts chronologically."""
        year = datetime.now(timezone.utc).year
        prefix = "MT-%d-" % year
        with self._lock:
            row = self._conn.execute(
                "SELECT case_number FROM cases WHERE case_number LIKE ? "
                "ORDER BY case_number DESC LIMIT 1", (prefix + "%",)).fetchone()
        if row:
            try:
                return "%s%04d" % (prefix, int(
                    str(row["case_number"]).split("-")[-1]) + 1)
            except ValueError:
                pass
        return prefix + "0001"

    # -- read --------------------------------------------------------------

    def get(self, case_id: str) -> Optional[Case]:
        with self._lock:
            row = self._conn.execute(
                "SELECT payload FROM cases WHERE id=? OR case_number=?",
                (case_id, case_id)).fetchone()
        if row is None:
            return None
        return Case.from_dict(json.loads(row["payload"]))

    def all_cases(self, limit: int = 500) -> List[Case]:
        """Full case objects, newest first. Used by correlation, which needs the
        artefacts rather than the summary."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT payload FROM cases ORDER BY created_at DESC LIMIT ?",
                (limit,)).fetchall()
        return [Case.from_dict(json.loads(r["payload"])) for r in rows]

    def queue(self,
              status: Optional[str] = None,
              verdict: Optional[str] = None,
              threat_class: Optional[str] = None,
              min_risk: Optional[float] = None,
              campaign_id: Optional[str] = None,
              include_duplicates: bool = True,
              sort: str = "created",
              limit: int = 100,
              offset: int = 0) -> Dict[str,
                                       Any]:
        """Filtered queue projection. Returns summaries, never full payloads."""
        where: List[str] = []
        args: List[Any] = []
        if status:
            where.append("status=?")
            args.append(status)
        if verdict:
            where.append("verdict=?")
            args.append(verdict)
        if threat_class:
            where.append("threat_class=?")
            args.append(threat_class)
        if min_risk is not None:
            where.append("risk_score>=?")
            args.append(float(min_risk))
        if campaign_id:
            where.append("campaign_id=?")
            args.append(campaign_id)
        if not include_duplicates:
            where.append("is_duplicate=0")
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        order = _SORTS.get(sort, _SORTS["created"])
        with self._lock:
            total = self._conn.execute(
                "SELECT COUNT(*) AS n FROM cases" + clause,
                args).fetchone()["n"]
            rows = self._conn.execute(
                "SELECT payload FROM cases%s ORDER BY %s LIMIT ? OFFSET ?"
                % (clause, order), args + [limit, offset]).fetchall()
        items = [
            Case.from_dict(
                json.loads(
                    r["payload"])).summary() for r in rows]
        return {"total": int(total), "count": len(items), "offset": offset,
                "sort": sort, "items": items}

    def search(self, query: str, limit: int = 50) -> Dict[str, Any]:
        """Full-text search across subject, sender, body, indicators and campaign.

        The FTS path also returns a snippet, which is what makes the result list
        useful rather than just a list of case numbers.
        """
        query = (query or "").strip()
        if not query:
            return {"backend": self.search_backend, "count": 0, "items": []}
        items: List[Dict[str, Any]] = []
        with self._lock:
            if self._fts:
                try:
                    rows = self._conn.execute(
                        "SELECT f.case_id AS cid, c.payload AS payload, "
                        "snippet(cases_fts, -1, '[', ']', '...', 12) AS snip "
                        "FROM cases_fts f JOIN cases c ON c.id = f.case_id "
                        "WHERE cases_fts MATCH ? ORDER BY rank LIMIT ?",
                        (_fts_query(query), limit)).fetchall()
                except sqlite3.OperationalError as exc:
                    log.info(
                        "FTS query rejected (%s); falling back to LIKE", exc)
                    rows = self._like_rows(query, limit)
            else:
                rows = self._like_rows(query, limit)
            for r in rows:
                summary = Case.from_dict(json.loads(r["payload"])).summary()
                summary["snippet"] = (r["snip"] if "snip" in r.keys() else "")
                items.append(summary)
        return {"backend": self.search_backend, "query": query,
                "count": len(items), "items": items}

    def _like_rows(self, query: str, limit: int) -> List[sqlite3.Row]:
        like = "%%%s%%" % query.replace("%", "").replace("_", "")
        return self._conn.execute(
            "SELECT id AS cid, payload, '' AS snip FROM cases WHERE subject LIKE ? "
            "OR sender_address LIKE ? OR sender_domain LIKE ? OR case_number LIKE ? "
            "OR campaign_id LIKE ? OR id IN (SELECT case_id FROM iocs WHERE value LIKE ?) "
            "ORDER BY created_at DESC LIMIT ?",
            (like, like, like, like, like, like, limit)).fetchall()

    def by_ioc(self, value: str, limit: int = 50) -> List[Dict[str, Any]]:
        """"Show me every case that touched this IP/domain/hash" - the pivot an
        analyst does constantly."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT c.payload AS payload FROM iocs i JOIN cases c ON c.id=i.case_id "
                "WHERE i.value = ? COLLATE NOCASE ORDER BY c.created_at DESC LIMIT ?",
                (value, limit)).fetchall()
        return [
            Case.from_dict(
                json.loads(
                    r["payload"])).summary() for r in rows]

    def campaigns(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Campaign roll-up: the grouping PS-26106 asks for, computed rather than
        stored, so it cannot drift from the cases themselves."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT campaign_id, COUNT(*) AS cases, MAX(risk_score) AS max_risk, "
                "AVG(risk_score) AS avg_risk, MIN(created_at) AS first_seen, "
                "MAX(created_at) AS last_seen, "
                "SUM(CASE WHEN verdict='phishing' THEN 1 ELSE 0 END) AS phishing, "
                "GROUP_CONCAT(DISTINCT sender_domain) AS domains, "
                "GROUP_CONCAT(DISTINCT threat_class) AS classes "
                "FROM cases WHERE campaign_id != '' GROUP BY campaign_id "
                "ORDER BY cases DESC, last_seen DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            out.append({
                "campaign_id": r["campaign_id"], "cases": int(r["cases"]),
                "max_risk": round(float(r["max_risk"] or 0), 1),
                "avg_risk": round(float(r["avg_risk"] or 0), 1),
                "first_seen": r["first_seen"], "last_seen": r["last_seen"],
                "phishing_cases": int(r["phishing"] or 0),
                "sender_domains": sorted(set((r["domains"] or "").split(",")) - {""}),
                "threat_classes": sorted(set((r["classes"] or "").split(",")) - {""}),
            })
        return out

    def stats(self) -> Dict[str, Any]:
        """Dashboard counters. One round trip, because the dashboard polls it."""
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN verdict='phishing' THEN 1 ELSE 0 END) AS phishing, "
                "SUM(CASE WHEN verdict='suspicious' THEN 1 ELSE 0 END) AS suspicious, "
                "SUM(CASE WHEN verdict='indeterminate' THEN 1 ELSE 0 END) AS indeterminate, "
                "SUM(CASE WHEN requires_review=1 AND action_status='pending' THEN 1 ELSE 0 END) "
                "  AS awaiting_review, "
                "SUM(CASE WHEN is_duplicate=1 THEN 1 ELSE 0 END) AS duplicates, "
                "SUM(CASE WHEN chain_simulated=0 THEN 1 ELSE 0 END) AS anchored, "
                "AVG(risk_score) AS avg_risk, AVG(confidence) AS avg_confidence "
                "FROM cases").fetchone()
            classes = self._conn.execute(
                "SELECT threat_class AS k, COUNT(*) AS n FROM cases "
                "WHERE threat_class IS NOT NULL GROUP BY threat_class").fetchall()
            actors = self._conn.execute(
                "SELECT actor_type AS k, COUNT(*) AS n FROM cases "
                "WHERE actor_type IS NOT NULL GROUP BY actor_type").fetchall()
            techniques = self._conn.execute(
                "SELECT technique AS k, COUNT(DISTINCT case_id) AS n FROM signals "
                "WHERE technique != '' GROUP BY technique ORDER BY n DESC LIMIT 10").fetchall()
            countries = self._conn.execute(
                "SELECT origin_country AS k, COUNT(*) AS n FROM cases "
                "WHERE origin_country != '' GROUP BY origin_country "
                "ORDER BY n DESC LIMIT 10").fetchall()
        return {
            "total": int(row["total"] or 0),
            "phishing": int(row["phishing"] or 0),
            "suspicious": int(row["suspicious"] or 0),
            "indeterminate": int(row["indeterminate"] or 0),
            "awaiting_review": int(row["awaiting_review"] or 0),
            "duplicates": int(row["duplicates"] or 0),
            "chain_anchored": int(row["anchored"] or 0),
            "avg_risk": round(float(row["avg_risk"] or 0), 1),
            "avg_confidence": round(float(row["avg_confidence"] or 0), 1),
            "threat_classes": {r["k"]: int(r["n"]) for r in classes},
            "actor_types": {r["k"]: int(r["n"]) for r in actors},
            "top_techniques": [{"technique": r["k"], "cases": int(r["n"])} for r in techniques],
            "top_origins": [{"country": r["k"], "cases": int(r["n"])} for r in countries],
            "search_backend": self.search_backend,
        }

    def audit_trail(self, case_id: str,
                    limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT event, actor, detail, at FROM audit WHERE case_id=? "
                "ORDER BY id DESC LIMIT ?", (case_id, limit)).fetchall()
        return [dict(r) for r in rows]

    # -- retention ---------------------------------------------------------

    def redact_expired(self, retention_days: Optional[int] = None,
                       dry_run: bool = True) -> Dict[str, Any]:
        """Strip message content from cases past the retention window.

        The case row itself is kept: verdict, hashes, IOCs, custody receipts and the
        report path remain, so the investigation is still provable and countable
        after the personal data inside it is gone. That is what "retention" has to
        mean for evidence - deleting the row would also delete the proof that the
        case was handled correctly.
        """
        days = int(retention_days if retention_days is not None
                   else get_settings().retention_days)
        cutoff = (
            datetime.now(
                timezone.utc) -
            timedelta(
                days=days)).isoformat()
        with self._lock:
            rows = self._conn.execute(
                "SELECT id, payload FROM cases WHERE created_at < ?", (cutoff,)).fetchall()
        affected: List[str] = []
        for r in rows:
            data = json.loads(r["payload"])
            pe = data.get("parsed_email", {})
            if not (pe.get("body_text") or pe.get(
                    "body_html") or pe.get("attachments")):
                continue
            affected.append(r["id"])
            if dry_run:
                continue
            pe["body_text"] = ""
            pe["body_html"] = ""
            for att in pe.get("attachments", []):
                att.pop("preview", None)
            keep = ("from", "to", "subject", "date", "message-id", "received",
                    "return-path", "reply-to", "authentication-results")
            pe["headers"] = [h for h in (pe.get("headers") or [])
                             if str(h.get("name", "")).lower() in keep]
            data.setdefault("privacy", {})["content_purged_at"] = utcnow()
            with self._lock:
                self._conn.execute(
                    "UPDATE cases SET payload=?, updated_at=? WHERE id=?", (json.dumps(
                        data, sort_keys=True), utcnow(), r["id"]))
                self._conn.commit()
            self.log_event(r["id"], "retention_purge", "system",
                           "message content removed after %d days" % days)
        return {"retention_days": days, "cutoff": cutoff, "dry_run": dry_run,
                "cases_affected": len(affected), "case_ids": affected[:50],
                "kept": "verdict, hashes, IOCs, signals, custody receipts, report path"}


def _fts_query(query: str) -> str:
    """Turn user input into a safe FTS5 MATCH expression.

    FTS5 treats a bare hyphen, quote or colon as syntax, so a search for
    ``payroll-update.example`` would otherwise raise. Each term is quoted, and a
    trailing ``*`` gives prefix matching on the last word, which is what makes
    type-as-you-search feel right.
    """
    terms = [t for t in re.split(r"\s+", query.strip()) if t]
    quoted = ['"%s"' % t.replace('"', '""') for t in terms[:-1]]
    if terms:
        last = terms[-1].replace('"', '""')
        quoted.append('"%s"*' % last if last.isalnum() else '"%s"' % last)
    return " AND ".join(quoted) or '""'


_store: Optional[CaseStore] = None
_store_lock = threading.Lock()


def get_store(path: Optional[str] = None) -> CaseStore:
    global _store
    with _store_lock:
        if _store is None or (path and str(_store.path) != str(Path(path))):
            _store = CaseStore(path)
        return _store


def reset_store() -> None:
    global _store
    with _store_lock:
        if _store is not None:
            try:
                _store.close()
            except sqlite3.Error:
                pass
        _store = None
